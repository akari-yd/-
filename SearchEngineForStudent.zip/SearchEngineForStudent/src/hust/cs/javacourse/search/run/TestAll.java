package hust.cs.javacourse.search.run;

import hust.cs.javacourse.search.index.AbstractPosting;
import hust.cs.javacourse.search.index.AbstractPostingList;
import hust.cs.javacourse.search.index.AbstractTermTuple;
import hust.cs.javacourse.search.index.impl.Posting;
import hust.cs.javacourse.search.index.impl.PostingList;
import hust.cs.javacourse.search.index.impl.TermTuple;
import hust.cs.javacourse.search.util.Config;

import java.util.ArrayList;
import java.util.List;

public class TestAll {
    public static void main(String[] args) {
        String s = "";
        System.out.println(Config.TERM_FILTER_PATTERN.equals(s));
    }
}
