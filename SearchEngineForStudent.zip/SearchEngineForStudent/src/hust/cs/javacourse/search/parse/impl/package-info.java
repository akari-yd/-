/**
 * 对hust.cs.javacourse.search.parse包里定义的抽象类和接口的具体实现放在这个包里。impl(implementation)
 */
package hust.cs.javacourse.search.parse.impl;